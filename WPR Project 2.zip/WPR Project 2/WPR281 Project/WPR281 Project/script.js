//Search button 

<script src="https://cdn.jsdelivr.net/npm/fuse.js@6.4.6"></script>

    const courses = [
        { title: "Higher Certificate", code: "HC101", duration: "1 year", description: "Introductory course.", modules: ["Module 1", "Module 2", "Module 3"], startDate: "2024-09-01" },
        { title: "Diploma", code: "DP102", duration: "2 years", description: "Intermediate course.", modules: ["Module A", "Module B", "Module C"], startDate: "2024-10-01" },
        { title: "BIT", code: "BIT103", duration: "3 years", description: "Bachelor in IT.", modules: ["Module X", "Module Y", "Module Z"], startDate: "2024-11-01" },
        { title: "BCOM", code: "BC104", duration: "3 years", description: "Bachelor in Commerce.", modules: ["Module L", "Module M", "Module N"], startDate: "2024-12-01" }
    ];

    const fuse = new Fuse(courses, {
        keys: ['title', 'code', 'description', 'modules'],
        includeScore: true
    });

    function searchFunction() {
        const input = document.getElementById('search-bar').value;
        const results = fuse.search(input);
        const resultsDiv = document.getElementById('results');
        resultsDiv.innerHTML = '';

        results.forEach(result => {
            const course = result.item;
            const div = document.createElement('div');
            div.textContent = `${course.title} (${course.code}): ${course.description}`;
            resultsDiv.appendChild(div);
        });
    }
//Quote Slide 
var slideIndex1 = 1;
showSlides1(slideIndex1);

function plusSlides1(n) {
  showSlides(slideIndex += n);
}

function currentSlide1(n) {
  showSlides(slideIndex = n);
}

function showSlides1(n) {
  var i;
  var slides = document.getElementsByClassName("Slides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex1 = 1}    
  if (n < 1) {slideIndex1 = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex1-1].style.display = "block";  
  dots[slideIndex1-1].className += " active";
}
//Slide index
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}

function displayCourses(courses) {
    const courseList = document.getElementById('course-list');
    courseList.innerHTML = ''; // Clear previous results
    courses.forEach(course => {
        const courseElement = document.createElement('article');
        courseElement.classList.add('course');
        courseElement.innerHTML = `
            <h2 class="course-title">${course.title}</h2>
            <p class="course-code">Code: ${course.code}</p>
            <p class="course-duration">Duration: ${course.duration}</p>
            <p class="course-description">${course.description}</p>
            <button class="view-details-button">View Details</button>
            <button class="enroll-button">Enroll</button>
        `;
        courseElement.querySelector('.view-details-button').addEventListener('click', () => showCourseDetails(course));
        courseElement.querySelector('.enroll-button').addEventListener('click', () => enrollCourse(course));
        courseList.appendChild(courseElement);
    });
}

function showCourseDetails(course) {
    const detailsSection = document.getElementById('course-details');
    detailsSection.innerHTML = `
        <h2>${course.title}</h2>
        <p>Code: ${course.code}</p>
        <p>Duration: ${course.duration}</p>
        <p>Description: ${course.description}</p>
        <h3>Modules:</h3>
        <ul id="module-list">${course.modules.map(module => `<li>${module}</li>`).join('')}</ul>
        <a href="study-guide.pdf" download>Download Study Guide</a>
        <iframe src="https://www.youtube.com/embed/some-video" frameborder="0" allowfullscreen></iframe>
        <button id="print-course">Print Course</button>
    `;

    document.getElementById('print-course').addEventListener('click', () => window.print());

    document.querySelectorAll('#module-list li').forEach(module => {
        module.addEventListener('click', function() {
            this.classList.toggle('completed');
            updateCompletedModules();
        });
    });
}

function updateCompletedModules() {
    const completedModules = document.querySelectorAll('#module-list .completed');
    const completedModulesList = document.getElementById('completed-modules-list');
    completedModulesList.innerHTML = Array.from(completedModules).map(module => `<li>${module.textContent}</li>`).join('');
}

function enrollCourse(course) {
    const enrollPage = `
        <div id="enroll-section">
            <h2>Enroll in ${course.title}</h2>
            <form id="enroll-form">
                <label for="name">Name:</label>
                <input type="text" id="name" required>
                <label for="email">Email:</label>
                <input type="email" id="email" required>
                <button type="submit">Submit</button>
            </form>
            <p id="countdown"></p>
        </div>
    `;

    document.body.innerHTML = enrollPage;

    document.getElementById('enroll-form').addEventListener('submit', function(event) {
        event.preventDefault();
        const startDate = new Date(course.startDate);
        setInterval(function() {
            const now = new Date();
            const timeDifference = startDate - now;
            const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
            document.getElementById('countdown').textContent = `Course starts in ${days} days`;
        }, 1000);
    });
}

 // Age validation
 function ageValidation() {
    let birthDate = new Date(document.querySelector("#birth").value);
    let currentDate = new Date();

    let age = currentDate.getFullYear() - birthDate.getFullYear();
    let month = currentDate.getMonth() - birthDate.getMonth();
    if (month < 0 || (month === 0 && currentDate.getDate() < birthDate.getDate())) {
        age--;
    }

    let text = "";
    if (age < 18) {
        text = "Invalid, not older than 18";
    }
    document.getElementById("demo").innerHTML = text;
    return text === ""; // Return true if valid
}

// Email validation
function emailValidation() {
    let email = document.querySelector("#email").value;
    let text = "";

    if (!email.includes(".icloud") && !email.includes(".gmail") && !email.includes(".outlook")) {
        text = "Invalid email address. It needs to include .icloud, .gmail, or .outlook.";
    } else if (email === "") {
        text = "Email address has not been filled.";
    }

    document.getElementById("demo2").innerHTML = text;
    return text === ""; // Return true if valid
}

// Function to check all validations
function checkValidations() {
    const isAgeValid = ageValidation();
    const isEmailValid = emailValidation();

    return isAgeValid && isEmailValid;
}

// Event listener for the submit button
document.getElementById("Submit").addEventListener("click", function() {
    const maxAttempts = 3; // Maximum number of attempts
    let attempts = 0;

    function tryValidation() {
        attempts++;
        if (checkValidations()) {
            // Proceed to the next page or next step
            alert("All validations passed. Proceeding to the next page...");
            window.location.href = 'table.html'; 
        } else if (attempts < maxAttempts) {
            alert("Validation failed. Please correct the errors.");
        } else {
            alert("Maximum attempts reached. Please try again later.");
        }
    }

    tryValidation();
});

// Event listener for the back button
document.getElementById("backEnroll").addEventListener("click", function() {
    
    window.history.back();
   
});
     
     //Course enrollment: Timer
     
     // Higher Certificate date
     var countDownDateh = new Date("Sept 1, 2024").getTime();
  
  var higherCertificate = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDateh - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    document.getElementById("HigherCertificate").innerHTML = days + " Days ";
  }, 1000);
  
  // Diploma date
  var countDownDated = new Date("Oct 1, 2024").getTime();
  
  var diploma = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDated - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    document.getElementById("Diploma").innerHTML = days + " Days ";
  }, 1000);
  
  // BIT date
  var countDownDateb = new Date("Nov 1, 2024").getTime();
  
  var BIT = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDateb - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    document.getElementById("BIT").innerHTML = days + " Days ";
  }, 1000);
  
  // BCOM date
  var countDownDatebc = new Date("Dec 1, 2024").getTime();
  
  var bcom = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDatebc - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    document.getElementById("BCOM").innerHTML = days + " Days ";
  }, 1000);

    //Contact page 
    
document.getElementById('contactForm').addEventListener('submit', function(event) { event.preventDefault();

    // Collect form data
    const formData = new FormData(event.target); const data = {
    name: formData.get('name'), surname: formData.get('surname'), phone: formData.get('phone'), email: formData.get('email'), campus: formData.get('campus'), info: formData.get('info'),
    message: formData.get('message')
    
    };
    
    
    // Send form data to the server
    fetch('https://your-server-endpoint.com/submit', { method: 'POST',
    headers: {
    'Content-Type': 'application/json'
    
    },
    body: JSON.stringify(data)
    })
    
    .then(response => response.json())
    .then(result => {
    alert('Your message has been sent!');
     
    // Reset form ﬁelds event.target.reset();
    })
    
    .catch(error => { console.error('Error:', error);
    alert('There was an error sending your message. Please try again later.');
    });
    });
    

